<div class="cart-btn">
    <a
        href=""
        data-bs-toggle="modal"
        data-bs-target="#shoppingCartModal"
    >
        <i class="bx bx-shopping-bag"></i>
        <span>{{ $cartCount }}</span>
    </a>
</div>
